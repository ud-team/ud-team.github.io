function init() { document.getElementById("Widget");
        if ( size == 100 ){document.getElementById("Widget").style.webkitTransform = 'scale(1.0)';}
        if ( size == 90 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.9)';
document.getElementById("Widget").style.left="-20px";}
        if ( size == 80 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.8)';
document.getElementById("Widget").style.left="-30px";}
        if ( size == 75 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.75)';
document.getElementById("Widget").style.left="-35px";}
        if ( size == 65 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.65)';
document.getElementById("Widget").style.left="-45px";}
        if ( size == 55 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.55)';
document.getElementById("Widget").style.left="-55px";}
        if ( size == 45 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.45)';
document.getElementById("Widget").style.left="-65px";}
 }