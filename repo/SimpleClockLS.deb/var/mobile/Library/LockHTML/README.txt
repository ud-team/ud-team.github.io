This is an example widget for the usage of WidgetInfo.plist and Options.plist in tandem.

Please place this widget in /var/mobile/Library/LockHTML, and select in Xen HTML to run on the lockscreen.

Thanks to the UniAW7 crew for the usage of this widget.